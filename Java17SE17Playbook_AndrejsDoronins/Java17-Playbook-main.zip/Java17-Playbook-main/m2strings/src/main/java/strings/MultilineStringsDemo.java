package strings;

public class MultilineStringsDemo {

    public static void main(String[] args) {

        String str = """
                To whom it may concern
                I wish you a good day
                Sincerely
                Me""";


        String textBlock =
                """
                        <html>
                            <body>
                                <tag>
                                </tag>
                            </body>
                        </html>""";

    }
}
