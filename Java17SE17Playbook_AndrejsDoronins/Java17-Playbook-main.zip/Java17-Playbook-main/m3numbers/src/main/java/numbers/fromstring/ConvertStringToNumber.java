package numbers.fromstring;

import java.util.List;

public class ConvertStringToNumber {

    public static void main(String[] args) {

        String num = "5";

        List<Integer> ints = List.of(Integer.valueOf(num));
        int primitiveNum = Integer.parseInt(num);

    }
}
